from django.contrib import admin
from .models import Clubs,Members,ClubMembership,Event,GalleryImage

@admin.register(Clubs)
class ClassAdmin(admin.ModelAdmin):
    list_display = ('name', 'description','logo', 'events_completed', 'total_members')
    search_fields = ('name',)

@admin.register(Members)
class MemberAdmin(admin.ModelAdmin):
    list_display = ('name', 'roll_number', 'year','password', 'department', 'photo', 'club_positions')
    search_fields = ('name', 'roll_number')

    def club_positions(self, obj):
        return ", ".join(
            f"{membership.club.name} ({membership.position})"
            for membership in ClubMembership.objects.filter(member=obj)
        )
    club_positions.short_description = 'Club Positions'

@admin.register(ClubMembership)
class ClubMembershipAdmin(admin.ModelAdmin):
    list_display = ('member', 'club', 'position')
    search_fields = ('member__name', 'club__name')


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('club','title','description','date','image')
    search_fields = ('title', 'club__name')


@admin.register(GalleryImage)
class GalleryImageAdmin(admin.ModelAdmin):
    list_display = ('club', 'uploaded_at')
    list_filter = ('club',)
