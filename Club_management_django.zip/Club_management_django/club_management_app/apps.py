from django.apps import AppConfig


class ClubManagementAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'club_management_app'
