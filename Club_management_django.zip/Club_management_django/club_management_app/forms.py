from django import forms
from .models import Members,Event

class SignUpForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Members
        fields = ['name', 'roll_number', 'password', 'year', 'department', 'photo']
    
class JoinClubRequestForm(forms.Form):
    roll_number = forms.CharField(max_length=9)
    message = forms.CharField(widget=forms.Textarea, required=False)

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['title', 'description', 'date', 'image']


        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }