from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


# class Category(models.Model):
#     title = models.CharField(max_length=255, unique=True)
#     description = models.TextField(blank=True, null=True)

#     def __str__(self):
#         return self.title

# class Event(models.Model):
#     club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='events') 
#     name = models.CharField(max_length=100)
#     date = models.DateField()
#     description = models.TextField()

#     def __str__(self):
#         return self.name


class Clubs(models.Model):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True,null=True)
    logo = models.ImageField(upload_to='clubs_logo/', blank=True, null=True) 
    events_completed = models.IntegerField(validators=[MinValueValidator(-1), MaxValueValidator(10000)],null=True,default=0)
    total_members = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(10000)],null=True,default=1) 
 
    def __str__(self):
        return self.name
    

class Members(models.Model):
    
    POSITION_CHOICES = [
        ('Head', 'Head'),
        ('Sub-head', 'Sub-head'),
        ('Member', 'Member'),
    ]

    clubs = models.ManyToManyField('Clubs', related_name='members')

    # club11 = models.ForeignKey(Clubs, on_delete=models.CASCADE, related_name='members')
    name = models.CharField(max_length=255)
    roll_number = models.CharField(max_length=9,null=True,default='EEE',blank=True)
    password = models.CharField(max_length=255, null=True, blank=True)
    # position = models.CharField(max_length=255,null=True,choices=POSITION_CHOICES ,default='Member')
    year = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(5)],null=False) 
    department = models.TextField(max_length=255,null=False)
    photo = models.ImageField(upload_to='memberPhoto/', blank=True, null=True) 
 
    def __str__(self): 
        return self.name
    
    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)



class JoinRequest(models.Model): 
    member = models.ForeignKey(Members, on_delete=models.CASCADE, related_name='join_requests') 
    club = models.ForeignKey(Clubs, on_delete=models.CASCADE, related_name='join_requests')
    timestamp = models.DateTimeField(default=timezone.now)  
    is_approved = models.BooleanField(default=False) 

    def __str__(self):
        return f"{self.member.name} requested to join {self.club.name}"

class ClubMembership(models.Model):
    member = models.ForeignKey(Members, on_delete=models.CASCADE)
    club = models.ForeignKey(Clubs, on_delete=models.CASCADE)
    position = models.CharField(max_length=20, choices=[('Head', 'Head'), ('Sub-Head', 'Sub-Head'), ('Member', 'Member')])

    class Meta:
        unique_together = ('member', 'club')


class Event(models.Model):
    club = models.ForeignKey(Clubs, on_delete=models.CASCADE, related_name='events')
    title = models.CharField(max_length=255)
    description = models.TextField()
    date = models.DateField()
    image = models.ImageField(upload_to='event_images/', blank=True, null=True)

    def __str__(self):
        return self.title


class GalleryImage(models.Model):
    club = models.ForeignKey('Clubs', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='gallery_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for {self.club.name} uploaded on {self.uploaded_at}"