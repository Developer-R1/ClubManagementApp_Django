from django.shortcuts import render, redirect , get_object_or_404
from django.contrib.auth import authenticate, login
from django.http import HttpResponse,HttpResponseForbidden
from .models import Members,Clubs,JoinRequest,ClubMembership,Event,GalleryImage
from django.contrib import messages
from django.views.decorators.http import require_POST
from .forms import SignUpForm,JoinClubRequestForm,EventForm




def landing_page(request):
    return render(request,'landing_page.html')

def clubs_display(request):
    clubs = Clubs.objects.all()
    return render(request,'club_display_page.html',{'clubs' : clubs} )

# def individual_clubs_page(request,club_id):
#     # members = Members.objects.all() 
#     club = Clubs.objects.get(id=club_id) 
#     # members = Members.objects.filter(clubs=club)

#     members = Members.objects.filter(clubmembership__club=club)

#     is_logged_in = request.session.get(f'club_{club_id}_logged_in', False)

#     show_login_button = not is_logged_in

#     show_inbox = False

#     show_request_to_join = True

#     inbox_request = []

#     member_id = request.session.get('member_id')

#     membership = ClubMembership.objects.filter(member=member, club=club).first()

#     if member_id:
#         member = Members.objects.get(id=member_id)
#         if club in member.clubs.all():
#             show_request_to_join = False

#         if member.position in ['Head','Sub-Head'] and club in member.clubs.all():
#             show_inbox = True
#             inbox_request = JoinRequest.objects.filter(club=club, is_approved = False)

#     return render(request, 'individual_clubs.html',{
#         'members': members,
#         'show_login_button': True,
#         'club': club,
#         'show_inbox':show_inbox,
#         'inbox_request':inbox_request,
#         'show_request_to_join':show_request_to_join,
#         })


def individual_clubs_page(request, club_id):
    club = get_object_or_404(Clubs, id=club_id)
    members = Members.objects.filter(clubmembership__club=club)

    memberships = ClubMembership.objects.filter(club=club).select_related('member')

    show_event_form = any(mem.position in ["Head", "Sub-Head"] for mem in memberships)


    show_login_button = True
    show_inbox = False
    show_request_to_join = True
    inbox_request = []

    member_id = request.session.get('member_id')
    
    if member_id:
        try:
            member = Members.objects.get(id=member_id)
            show_login_button = False

            membership = ClubMembership.objects.filter(member=member, club=club).first()

            if membership:
                show_request_to_join = False

                if membership.position in ['Head', 'Sub-Head']:
                    show_inbox = True
                    inbox_request = JoinRequest.objects.filter(club=club, is_approved=False)

        except Members.DoesNotExist:
            pass

  
    # if request.method == 'POST':
    #     form = EventForm(request.POST, request.FILES)
    #     if form.is_valid():
    #         event = form.save(commit=False)
    #         event.club = club
    #         event.save()
    #         return redirect('individual_clubs_page', club_id=club.id)
    #     else:
    #         print("Form errors:", form.errors)
    # else:
    #     form = EventForm()

    # events = Event.objects.filter(club=club)

    events = Event.objects.filter(club=club).order_by('-date')


    return render(request, 'individual_clubs.html', {
        'members': members,
        'events': events,
        # 'form':form,
        'club': club,
        'memberships': memberships,
        'show_login_button': show_login_button,
        'show_inbox': show_inbox,
        'inbox_request': inbox_request,
        'show_request_to_join': show_request_to_join,
        'show_event_form':show_event_form,
    })



def custom_login(request):
    if request.method == 'POST':
        roll_number = request.POST.get('roll_number')
        password = request.POST.get('password')

        try:
            member = Members.objects.get(roll_number=roll_number)
            if member.password == password:  # replace with secure check if hashed
                request.session['member_id'] = member.id
                messages.success(request, f"Welcome {member.name}!")
                return redirect('landing_page')  # or individual club page
            else:
                messages.error(request, "Invalid password")
        except Members.DoesNotExist:
            messages.error(request, "Member with this roll number does not exist")

    # request.session['member_id'] = member.id
    # request.session['roll_number'] = member.roll_number
    # request.session[f'club_{club_id}_logged_in'] = True


    return render(request, 'login.html')

@require_POST
def approve_request(request,request_id):
    join_request = JoinRequest.objects.get(id=request_id)
    join_request.is_approved = True
    join_request.save()

    # join_request.member.clubs.add(join_request.club)

    ClubMembership.objects.create(member=join_request.member, club=join_request.club, position='Member')

    return redirect('individual_clubs_page',club_id=join_request.club.id)



def SignUpView(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST, request.FILES)
        if form.is_valid():
            member = form.save(commit=False)
            # member.set_password(form.cleaned_data['password'])  
            
            member.save()
            messages.success(request, "Signup successful! You can now log in.")
            return redirect('landing_page') 
    else:
        form = SignUpForm()
    
    return render(request, 'sign_up.html', {'form': form})



def request_to_join_club_view(request, club_id):
    club = get_object_or_404(Clubs, id=club_id)

    if request.method == 'POST':
        form = JoinClubRequestForm(request.POST)
        if form.is_valid():
            roll = form.cleaned_data['roll_number']
            message = form.cleaned_data['message']

            try:
                member = Members.objects.get(roll_number=roll)
                if ClubMembership.objects.filter(member=member, club=club).exists():
                    messages.warning(request, "You are already a member of this club.")
                else:
                    JoinRequest.objects.create(member=member, club=club)
                    messages.success(request, "Your request has been sent.")
            except Members.DoesNotExist:
                messages.error(request, "No user found with that roll number.")
            return redirect('individual_clubs_page', club_id=club_id)
    else:
        form = JoinClubRequestForm()

    return render(request, 'request_to_join.html', {'form': form, 'club': club})


def profile_view(request):

    member_id = request.session.get('member_id')
    if not member_id:
        messages.error(request, "Please Sign up to view your profile.")
        
        return redirect('landing_page')
    
    member = Members.objects.get(id=member_id)
    memberships = ClubMembership.objects.filter(member=member)
    return render(request, 'profile.html', {'member': member, 'memberships': memberships})


def logout_view(request):
    try:
        del request.session['member_id']
        messages.success(request, "You have been logged out successfully.")
    except KeyError:
        messages.info(request, "You were not logged in.")
    return redirect('landing_page')



def get_user_role(member, club):
    membership = ClubMembership.objects.filter(member=member, club=club).first()
    if membership:
        return membership.position
    return None

def add_event(request, club_id):
    club = get_object_or_404(Clubs, id=club_id)

    if request.method == "POST":
        form = EventForm(request.POST, request.FILES)
        if form.is_valid():
            event = form.save(commit=False)
            event.club = club
            event.save()
            return redirect('individual_clubs_page', club_id=club.id)
    else:
        form = EventForm()

    return render(request, 'events.html', {
        'form': form,
        'club': club,
    })

# def delete_event(request, event_id):
#     event = get_object_or_404(Event, id=event_id)
#     club = event.club
#     member_id = request.session.get('member_id')
#     member = get_object_or_404(Members, id=member_id)

#     role = get_user_role(member, club)
#     if role not in ['Head', 'Sub-Head']:
#         return HttpResponseForbidden("Not authorized")

#     event.delete()
#     messages.success(request, "Event deleted.")
#     return redirect('individual_clubs', club_id=club.id)


def add_gallery_image(request, club_id):
    if request.method == 'POST':
        club = get_object_or_404(Clubs, id=club_id)
        member_id = request.session.get('member_id')
        member = get_object_or_404(Members, id=member_id)

        role = get_user_role(member, club)
        if role not in ['Head', 'Sub-Head']:
            return HttpResponseForbidden("Not authorized")

        image = request.FILES['image']
        GalleryImage.objects.create(club=club, image=image)
        messages.success(request, "Image uploaded.")
    return redirect('individual_clubs', club_id=club_id)


def delete_gallery_image(request, image_id):
    image = get_object_or_404(GalleryImage, id=image_id)
    club = image.club
    member_id = request.session.get('member_id')
    member = get_object_or_404(Members, id=member_id)

    role = get_user_role(member, club)
    if role not in ['Head', 'Sub-Head']:
        return HttpResponseForbidden("Not authorized")

    image.delete()
    messages.success(request, "Image deleted.")
    return redirect('individual_clubs', club_id=club.id)
