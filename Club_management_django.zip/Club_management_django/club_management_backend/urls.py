from django.contrib import admin
from django.urls import path, include
from club_management_app.views import landing_page,individual_clubs_page,custom_login,clubs_display,approve_request,SignUpView,request_to_join_club_view,profile_view,logout_view,add_event
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path('clubs/', include('club_management_app.urls')),
    path('', landing_page,name='landing_page'),
    path('clubs1/',clubs_display),
    path('login/', custom_login, name='login'),
    path('clubs2/<int:club_id>/',individual_clubs_page,name='individual_clubs_page' ),
    path('approve-request/<int:request_id>/',approve_request, name='approve_request'),
    path('signup/',SignUpView, name = 'signup'),
    path('club/<int:club_id>/request/', request_to_join_club_view, name='request_to_join'),
    path('profile/', profile_view, name ='profile'),
    path('logout/', logout_view, name='logout'),

    path('club/<int:club_id>/add_event/', add_event, name='add_event'),

    # path('clubs/<int:club_id>/add_event/', add_event, name='add_event'),
    # path('events/<int:event_id>/delete/', delete_event, name='delete_event'),

    # path('clubs/<int:club_id>/add_image/', add_gallery_image, name='add_gallery_image'),
    # path('gallery/<int:image_id>/delete/', delete_gallery_image, name='delete_gallery_image')

]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)